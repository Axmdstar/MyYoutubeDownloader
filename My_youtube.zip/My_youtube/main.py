from gui import Ui

test = Ui()

# Test
# https://youtube.com/shorts/p7jPo7mGqV0?feature=share

# short
#https://www.youtube.com/watch?v=dSPiDFZmAnQ

# complete progress bar or just display as %s ⬅️ ✔️
# threads : download , search , size change ✔️
# brower default value ✔️
# Catch Errors , download without selecting res ✔️
# fix videe res picked before search is click ✔️
# 144p and 240p IndexError we can't download 144p and 240p 😖
# 360 and 720p are the only streams that come with audio 

# Styles
